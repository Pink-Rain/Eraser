(function () {
  'use strict';
  const VERSION = '0.10.0';
  const API = 'http://127.0.0.1:32147/api/roll20/bridge';
  const IS_TOP = window.top === window;
  let syncing = false;
  const acknowledgements = new Map();
  const observedAcknowledgements = new Set();
  const observedRoots = new WeakSet();
  const chatRootList = [];
  let acknowledgementPoll = null;

  /* ---------- utilitaires ---------- */
  const encode = (value) => btoa(unescape(encodeURIComponent(JSON.stringify(value)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
  const decode = (value) => {
    let input = value.replace(/-/g, '+').replace(/_/g, '/');
    while (input.length % 4) input += '=';
    return JSON.parse(decodeURIComponent(escape(atob(input))));
  };
  const rid = () => Math.random().toString(36).slice(2, 12);
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const storageGet = (key) => new Promise((resolve) => chrome.storage.local.get([key], (result) => resolve(result[key] || '')));
  const storageSet = (value) => new Promise((resolve) => chrome.storage.local.set(value, resolve));
  const runtimeMessage = (message) => new Promise((resolve) => chrome.runtime.sendMessage(message, resolve));
  const bridgeFetch = (options) => runtimeMessage({ type: 'eraser-fetch', ...options });

  /* ---------- dossiers du Journal (via page.js, dans la page Roll20) ---------- */
  function moveToJournalFolder(folder, ids) {
    return new Promise((resolve, reject) => {
      const requestId = rid();
      const timer = setTimeout(() => { window.removeEventListener('message', listener); reject(new Error('La page Roll20 n’a pas répondu pour le dossier « ' + folder + ' ».')); }, 8000);
      function listener(event) {
        const data = event.data;
        if (event.source !== window || !data || data.source !== 'eraser-page' || data.requestId !== requestId) return;
        clearTimeout(timer);
        window.removeEventListener('message', listener);
        if (data.ok) resolve(data.moved || 0); else reject(new Error(data.error || 'Dossier impossible à créer.'));
      }
      window.addEventListener('message', listener);
      window.postMessage({ source: 'eraser-companion', type: 'journal-folder', requestId, folder, ids }, '*');
    });
  }

  /* ---------- accusés de réception du Mod ---------- */
  function waitForAcknowledgement(id, timeoutMs = 12000, timeoutMessage) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        acknowledgements.delete(id);
        reject(new Error(timeoutMessage || 'Le script Mod Roll20 ne répond pas. Vérifie dans la console Mod que « Eraser Bridge ' + VERSION + ' prêt » apparaît.'));
      }, timeoutMs);
      acknowledgements.set(id, {
        resolve: (metadata) => {
          clearTimeout(timer);
          acknowledgements.delete(id);
          if (metadata?.error) reject(new Error(metadata.error));
          else resolve(metadata || {});
        },
        cancel: () => { clearTimeout(timer); acknowledgements.delete(id); },
      });
      scanAllChatRoots();
    });
  }

  function scanAcknowledgements(text) {
    for (const match of String(text || '').matchAll(/ERASER_ACK:([A-Za-z0-9_-]+)(?::([A-Za-z0-9_-]+))?/g)) {
      const id = match[1];
      let metadata = {};
      try { if (match[2]) metadata = decode(match[2]); } catch { metadata = {}; }
      acknowledgements.get(id)?.resolve(metadata);
      if (!observedAcknowledgements.has(id)) {
        observedAcknowledgements.add(id);
        void storageSet({ eraserLastAcknowledgement: { id, metadata, at: Date.now() } });
      }
    }
  }
  function scanAllChatRoots() { for (const root of chatRootList) scanAcknowledgements(root.textContent || ''); }

  /* ---------- chat ---------- */
  function chatElements() {
    const input = document.querySelector('#textchat-input textarea, textarea.ui-autocomplete-input, textarea[placeholder*="chat" i], textarea[aria-label*="chat" i]');
    const container = input && (input.closest('#textchat-input') || input.parentElement);
    const form = input && input.closest('form');
    const candidates = [...new Set([
      ...(form ? form.querySelectorAll('button[type="submit"], input[type="submit"], button') : []),
      ...(container ? container.querySelectorAll('button[type="submit"], input[type="submit"], button') : []),
    ])];
    const button = candidates.find((c) => c.matches('[type="submit"]')) || candidates.find((c) => /envoyer|send|chat/i.test([c.textContent, c.getAttribute('aria-label'), c.getAttribute('title')].filter(Boolean).join(' ')));
    return { input, form, button };
  }

  async function sendCommand(command) {
    const { input, form, button } = chatElements();
    if (!input) throw new Error('Le champ de chat Roll20 est introuvable. Ouvre l’onglet Chat puis réessaie.');
    input.focus();
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), 'value')?.set;
    if (setter) setter.call(input, command); else input.value = command;
    input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: command }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(50);
    if (button && !button.matches('[type="submit"]')) button.click();
    else if (form && typeof form.requestSubmit === 'function') form.requestSubmit(button || undefined);
    else if (button) button.click();
    else {
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    }
    for (let attempt = 0; attempt < 10 && input.value.trim() === command; attempt += 1) await sleep(100);
    if (input.value.trim() === command) throw new Error('La commande Eraser est restée dans le chat Roll20 sans être envoyée. Ouvre l’onglet Chat puis réessaie.');
    await sleep(120);
  }

  // Envoie une commande et attend l'accusé correspondant.
  async function command(prefix, payload, timeoutMs, timeoutMessage) {
    const syncId = payload?.syncId || rid();
    const pending = waitForAcknowledgement(syncId, timeoutMs, timeoutMessage);
    try {
      await sendCommand(payload ? prefix + ' ' + encode({ ...payload, syncId }) : prefix + ' ' + syncId);
      return await pending;
    } catch (error) {
      acknowledgements.get(syncId)?.cancel();
      throw error;
    }
  }

  async function checkModBridge() {
    const result = await command('!eraser-ping', null, 8000, 'Le script Mod Eraser Bridge ne répond pas. Installe la version ' + VERSION + ' et vérifie la console Mod.');
    if (result.version !== VERSION) throw new Error('Le script Mod est en version ' + (result.version || 'ancienne') + ', l’extension en ' + VERSION + '. Mets le script Mod à jour.');
  }

  async function importPayload(payload) {
    const syncId = rid();
    const encoded = encode({ ...payload, syncId });
    const pending = waitForAcknowledgement(syncId, 15000);
    try {
      if (encoded.length <= 3500) await sendCommand('!eraser-import ' + encoded);
      else {
        const parts = [];
        for (let offset = 0; offset < encoded.length; offset += 3000) parts.push(encoded.slice(offset, offset + 3000));
        for (let index = 0; index < parts.length; index += 1) await sendCommand('!eraser-chunk ' + syncId + ' ' + index + '/' + parts.length + ' ' + parts[index]);
        await sendCommand('!eraser-chunk-done ' + syncId);
      }
      return await pending;
    } catch (error) {
      acknowledgements.get(syncId)?.cancel();
      throw error;
    }
  }

  /* ---------- portraits ---------- */
  function dataUrlToBlob(dataUrl) {
    const match = String(dataUrl).match(/^data:([^;,]+)(;base64)?,(.*)$/);
    if (!match) throw new Error('Le portrait reçu depuis Eraser est invalide.');
    const binary = match[2] ? atob(match[3]) : decodeURIComponent(match[3]);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: match[1] });
  }

  // Roll20 accepte png/jpg/gif ; on convertit le reste (webp, avif…) et on réduit les images énormes.
  async function toUploadableFile(dataUrl, name) {
    let blob = dataUrlToBlob(dataUrl);
    const safeName = (String(name || 'portrait').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9_-]+/gi, '-').replace(/^-|-$/g, '') || 'portrait');
    const accepted = /^image\/(png|jpe?g|gif)$/i.test(blob.type);
    let bitmap = null;
    try { bitmap = await createImageBitmap(blob); } catch { if (!accepted) throw new Error('Le portrait n’est pas une image lisible (' + (blob.type || 'type inconnu') + ').'); }
    const tooBig = bitmap && (bitmap.width > 1400 || bitmap.height > 1400 || blob.size > 4 * 1024 * 1024);
    if (bitmap && (!accepted || tooBig) && !/gif/i.test(blob.type)) {
      const scale = Math.min(1, 1400 / Math.max(bitmap.width, bitmap.height));
      const canvas = new OffscreenCanvas(Math.round(bitmap.width * scale), Math.round(bitmap.height * scale));
      canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      blob = await canvas.convertToBlob({ type: 'image/png' });
    }
    bitmap?.close?.();
    const extension = blob.type.split('/')[1].replace('jpeg', 'jpg');
    return new File([blob], safeName + '.' + extension, { type: blob.type });
  }

  // La table de jeu : le plus grand canvas visible de l'éditeur.
  function tabletopTarget() {
    const canvases = [...document.querySelectorAll('#editor-wrapper canvas, #editor canvas, canvas')]
      .filter((c) => { const r = c.getBoundingClientRect(); return r.width > 200 && r.height > 200 && getComputedStyle(c).visibility !== 'hidden'; });
    canvases.sort((a, b) => {
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      return rb.width * rb.height - ra.width * ra.height;
    });
    const canvas = canvases[0];
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const x = Math.round(rect.left + rect.width / 2);
    const y = Math.round(rect.top + rect.height / 2);
    // On vise l'élément réellement au premier plan (Roll20 empile plusieurs canvas).
    const top = document.elementFromPoint(x, y);
    const target = top && (top === canvas || canvas.parentElement?.contains(top)) ? top : canvas;
    return { target, x, y };
  }

  // Imite le glisser-déposer d'un fichier sur la table : Roll20 l'envoie
  // dans ta bibliothèque avec son propre pipeline, et le Mod capture le résultat.
  function dropFileOnTabletop(file) {
    const spot = tabletopTarget();
    if (!spot) throw new Error('La table de jeu Roll20 est introuvable (reste sur l’onglet de la carte pendant la synchro).');
    const transfer = new DataTransfer();
    transfer.items.add(file);
    const init = { bubbles: true, cancelable: true, composed: true, clientX: spot.x, clientY: spot.y, screenX: spot.x, screenY: spot.y, dataTransfer: transfer };
    for (const type of ['dragenter', 'dragover', 'drop']) spot.target.dispatchEvent(new DragEvent(type, init));
  }

  // role 'avatar' : le portrait de la fiche ; role 'token' : le token rond d'Eraser.
  async function downloadImage(url, what) {
    const image = await runtimeMessage({ type: 'eraser-image', url: new URL(url, API).href });
    if (!image?.ok) throw new Error(image?.error || 'Le ' + what + ' Eraser n’a pas pu être téléchargé.');
    return image.dataUrl;
  }

  async function imageFrom(url, what) {
    const image = new Image();
    const dataUrl = await downloadImage(url, what);
    await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error('Le ' + what + ' n’est pas une image lisible.')); image.src = dataUrl; });
    return image;
  }

  // Les images des cadres (public/token-frames d'Eraser), téléchargées une fois par page.
  const frameImages = new Map();
  function frameImage(url) {
    if (!frameImages.has(url)) frameImages.set(url, imageFrom(url, 'cadre').catch((error) => { frameImages.delete(url); throw error; }));
    return frameImages.get(url);
  }

  // Sans token préparé dans Eraser : le token que l'éditeur de token aurait fait, avec le cadre
  // choisi (sinon celui par défaut) et l'avatar cadré comme dans Eraser (token-art.js).
  async function defaultTokenFile(kind, value) {
    const art = globalThis.EraserTokenArt;
    if (!art) throw new Error('Le dessin des tokens est absent du compagnon.');
    const image = value.portraitUrl ? await imageFrom(value.portraitUrl, 'portrait') : null;
    let canvas = null;
    if (value.frame?.front && art.renderFramedToken) {
      try {
        const [front, back, interior] = await Promise.all([frameImage(value.frame.front), value.frame.back ? frameImage(value.frame.back) : null, !image && value.frame.interior ? frameImage(value.frame.interior) : null]);
        canvas = art.renderFramedToken({ front, back, interior, radius: value.frame.radius }, image, value.framing || null);
      } catch { canvas = null; /* cadre introuvable : le dessin intégré au compagnon */ }
    }
    if (!canvas) {
      const style = kind === 'shop'
        ? { kind: 'shop', shopKey: art.shopFronts[value.key] ? value.key : 'market' }
        : { kind: kind === 'character' ? 'character' : kind === 'creature' ? 'creature' : 'npc' };
      canvas = art.renderDefaultToken(style, image, value.framing || null);
    }
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('Le token par défaut n’a pas pu être dessiné.');
    return new File([blob], (String(value.name || 'token').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9_-]+/gi, '-') || 'token') + '-token.png', { type: 'image/png' });
  }

  async function uploadImage(imported, source, name, role, options) {
    const file = source instanceof File
      ? source
      : await toUploadableFile(await downloadImage(source, role === 'token' ? 'token' : role === 'handout' ? 'document' : 'portrait'), name + (role === 'token' ? '-token' : ''));
    const doneId = rid();
    const done = waitForAcknowledgement(doneId, 60000, 'Roll20 n’a pas renvoyé l’image importée en 60 s (upload bloqué ou table de jeu non visible).');
    try {
      await command('!eraser-expect-portrait', {
        characterId: imported.characterId,
        eraserId: imported.eraserId,
        hash: role === 'token' ? imported.tokenHash : imported.portraitHash,
        role,
        tokenFollows: Boolean(options?.tokenFollows),
        bar: options?.bar !== false,
        doneId,
      }, 10000);
      dropFileOnTabletop(file);
      return await done;
    } catch (error) {
      acknowledgements.get(doneId)?.cancel();
      await sendCommand('!eraser-cancel-portrait').catch(() => {});
      throw error;
    }
  }

  /**
   * Importe une fiche puis, si besoin, son portrait et son token.
   * Renvoie { imported, portrait, token, failures, warnings }.
   */
  async function importWithImages(payload, kind, value, label, folder) {
    const report = { imported: false, portrait: false, token: false, eraserToken: false, autoToken: false, characterId: '', failures: [], warnings: [] };
    const bar = kind !== 'shop';
    // Aucun token préparé : le compagnon fabrique le token par défaut. Son empreinte
    // suit le portrait, il est donc refait quand l'avatar change dans Eraser.
    const automatic = !value.tokenUrl && (Boolean(value.portraitUrl) || kind === 'shop');
    // « auto3 » : le token par défaut suit aussi le cadrage de l'avatar et le cadre choisi
    // dans Eraser (il est refait quand l'un d'eux change).
    const framingKey = value.framing ? [value.framing.x, value.framing.y, value.framing.span].map((number) => Math.round(Number(number) * 1000)).join(',') : '';
    const sent = automatic ? { ...value, tokenUrl: 'auto3:' + (value.portraitUrl || 'shop:' + value.key) + ':' + (value.portraitVersion || '') + ':' + framingKey + ':' + (value.frame?.id || '') } : value;
    let result;
    try {
      result = await importPayload({ campaign: payload.campaign, kind, value: sent, folder: folder || '' });
      if (!result.characterId) throw new Error('Roll20 n’a pas confirmé la création de la fiche.');
      report.imported = true;
      report.characterId = result.characterId;
    } catch (error) {
      report.failures.push(value.name + ' : import — ' + error.message);
      return report;
    }
    if (result.needsAvatar) {
      status(label + ' (portrait)');
      try {
        const portrait = await uploadImage(result, value.portraitUrl, value.name, 'avatar', { tokenFollows: result.needsToken, bar });
        report.portrait = true;
        if (portrait.token) report.token = true;
      } catch (error) { report.failures.push(value.name + ' : portrait — ' + error.message); }
    }
    if (result.needsToken) {
      status(label + ' (token)');
      try {
        const token = await uploadImage(result, automatic ? await defaultTokenFile(kind, value) : value.tokenUrl, value.name, 'token', { bar });
        if (automatic) report.autoToken = true; else report.eraserToken = true;
        if (token.token) report.token = true;
      } catch (error) { report.failures.push(value.name + ' : token — ' + error.message); }
    }
    if (!report.token && (result.needsAvatar || result.needsToken) && kind !== 'shop') {
      // Image manquante : on configure quand même le jeton (image existante ou image par défaut).
      try {
        const fallback = await command('!eraser-token', { characterId: result.characterId, eraserId: result.eraserId, bar }, 12000);
        if (fallback.token) report.token = true; else report.warnings.push(value.name + ' : jeton en attente — ' + fallback.reason);
      } catch (tokenError) { report.failures.push(value.name + ' : jeton — ' + tokenError.message); }
    } else if (!result.needsAvatar && !result.needsToken && kind !== 'shop') {
      if (result.token) report.token = true;
      else report.warnings.push(value.name + ' : jeton en attente — ' + (result.reason || 'raison inconnue'));
    }
    return report;
  }

  /* ---------- documents ---------- */
  async function downloadFile(url, name, type) {
    const file = await runtimeMessage({ type: 'eraser-file', url: new URL(url, API).href });
    if (!file?.ok) throw new Error(file?.error || 'Le fichier n’a pas pu être téléchargé depuis Eraser.');
    const blob = dataUrlToBlob(file.dataUrl);
    return new File([blob], name, { type: type || blob.type });
  }

  const safeFileName = (value, fallback) => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 _-]+/gi, '').trim().replace(/\s+/g, ' ') || fallback;

  function visible(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && getComputedStyle(element).visibility !== 'hidden';
  }
  // La page et ses racines fantômes (shadow DOM) : l'interface de Roll20 en utilise.
  function queryAll(selector) {
    const found = [...document.querySelectorAll(selector)];
    for (const root of chatRootList) if (root !== document.body && root.querySelectorAll) found.push(...root.querySelectorAll(selector));
    return [...new Set(found)];
  }
  const labelOf = (element) => [element.textContent, element.getAttribute('aria-label'), element.getAttribute('title')].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  const pdfInput = () => queryAll('input[type="file"]').find((input) => /pdf/i.test(input.accept || ''));
  async function waitFor(find, timeoutMs) {
    for (const until = Date.now() + timeoutMs; Date.now() < until; await sleep(150)) {
      const found = find();
      if (found) return found;
    }
    return null;
  }

  /**
   * Dépose le PDF dans le Journal comme le MJ le ferait : onglet Journal › « + Ajouter » ›
   * « PDF », puis le fichier choisi dans la fenêtre d'envoi. Le Mod ne peut pas créer de PDF.
   * Si l'un des boutons est introuvable (interface de Roll20 changée), rien d'autre n'est
   * cliqué : l'appelant télécharge alors le PDF pour que le MJ le glisse lui-même.
   */
  async function uploadPdfToJournal(file) {
    let input = pdfInput();
    if (!input) {
      const tab = queryAll('a[href="#journal"], [data-tab="journal"], button[aria-label="Journal"], [title="Journal"]').find(visible);
      if (tab) { tab.click(); await sleep(350); }
      const journal = document.getElementById('journal') || document;
      const add = [...journal.querySelectorAll('button, a, .btn, [role="button"]')].filter(visible).find((element) => /^\+?\s*(add|ajouter)$/i.test(labelOf(element)));
      if (!add) throw new Error('bouton « + Ajouter » du Journal introuvable');
      add.click();
      const item = await waitFor(() => queryAll('li, a, button, [role="menuitem"], [role="option"]').filter(visible).find((element) => /^pdf$/i.test(labelOf(element))), 3000);
      if (!item) { add.click(); throw new Error('choix « PDF » du menu « + Ajouter » introuvable'); }
      item.click();
      input = await waitFor(pdfInput, 8000);
      if (!input) throw new Error('fenêtre d’envoi du PDF introuvable');
    }
    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(700);
    // Une fenêtre qui attend encore sa confirmation : seul un bouton d'envoi explicite est cliqué.
    const dialog = input.closest('[role="dialog"], dialog, .modal, .ui-dialog') || null;
    const confirm = dialog && [...dialog.querySelectorAll('button')].filter((button) => visible(button) && !button.disabled).find((button) => /^(upload|téléverser|televerser|importer|envoyer|charger|ajouter le pdf|add pdf)/i.test(labelOf(button)));
    if (confirm) confirm.click();
  }

  function saveFileLocally(file) {
    const url = URL.createObjectURL(file);
    const link = Object.assign(document.createElement('a'), { href: url, download: file.name });
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  /**
   * Un document d'Eraser : un handout (son image, lisible tout de suite) et son PDF dans le
   * Journal. Le PDF n'est redéposé que si le document a changé depuis le dernier envoi.
   */
  async function importDocument(payload, doc, label, folder) {
    const report = { imported: false, image: false, pdf: false, pdfSaved: false, characterId: '', failures: [], warnings: [] };
    let result;
    try {
      result = await importPayload({ campaign: payload.campaign, kind: 'document', value: { id: doc.id, name: doc.name, imageUrl: doc.imageUrl }, folder: folder || '' });
      if (!result.handoutId) throw new Error('Roll20 n’a pas confirmé la création du handout.');
      report.imported = true;
      report.characterId = result.handoutId;
    } catch (error) {
      report.failures.push(doc.name + ' : document — ' + error.message);
      return report;
    }
    if (result.needsImage) {
      status(label + ' (image)');
      try {
        await uploadImage(result, doc.imageUrl, doc.name, 'handout', { bar: false });
        report.image = true;
      } catch (error) { report.failures.push(doc.name + ' : image — ' + error.message); }
    }
    if (doc.pdfUrl) {
      const sent = (await storageGet('eraserPdfs')) || {};
      const key = gameId() + ':' + doc.id;
      if (sent[key] !== doc.version) {
        status(label + ' (PDF)');
        let file = null;
        try {
          file = await downloadFile(doc.pdfUrl, safeFileName(doc.name, 'document') + '.pdf', 'application/pdf');
          await uploadPdfToJournal(file);
          report.pdf = true;
          await storageSet({ eraserPdfs: { ...sent, [key]: doc.version } });
        } catch (error) {
          if (file) {
            saveFileLocally(file);
            report.pdfSaved = true;
            report.warnings.push(doc.name + ' : PDF téléchargé sur ton ordinateur (' + error.message + '). Glisse-le dans Journal › + Ajouter › PDF.');
          } else report.failures.push(doc.name + ' : PDF — ' + error.message);
        }
      }
    }
    return report;
  }

  /* ---------- panneau ---------- */
  function status(message, error) {
    const node = document.getElementById('eraser-roll20-status');
    if (!node) return;
    node.textContent = message;
    node.dataset.error = error ? '1' : '0';
  }
  const openPanel = () => document.getElementById('eraser-roll20-panel')?.classList.add('open');
  const closePanel = () => document.getElementById('eraser-roll20-panel')?.classList.remove('open');

  function gameId() {
    const query = new URL(location.href).searchParams;
    return query.get('campaign') || query.get('id') || location.pathname.split('/').filter(Boolean).pop() || 'roll20-game';
  }
  const gameName = () => document.title.replace(/\s*\|\s*Roll20.*$/i, '').trim() || 'Partie Roll20';

  // `scope` : « players » (personnages joueurs seuls) ou « documents » (documents seuls).
  async function fetchCampaign(sessionId, scope) {
    const token = await storageGet('eraserToken');
    if (!token) throw new Error('Colle d’abord la clé créée dans Eraser.');
    const url = API + '?gameId=' + encodeURIComponent(gameId()) + '&gameName=' + encodeURIComponent(gameName()) + (sessionId ? '&session=' + encodeURIComponent(sessionId) : '') + (scope ? '&view=' + encodeURIComponent(scope) : '');
    const response = await bridgeFetch({ url, headers: { authorization: 'Bearer ' + token } });
    if (!response?.ok) throw new Error(response?.payload?.error || 'Connexion à Eraser impossible.');
    if (response.payload?.schema !== 2) throw new Error('Version de données Eraser incompatible (schema ' + (response.payload?.schema ?? 'absent') + '). Mets à jour l’application, le compagnon et le Mod en ' + VERSION + '.');
    return response.payload;
  }

  /* ---------- sessions ---------- */
  let sessionList = [];

  async function fetchSessions() {
    const token = await storageGet('eraserToken');
    if (!token) throw new Error('Colle d’abord la clé créée dans Eraser.');
    const response = await bridgeFetch({ url: API + '?view=sessions', headers: { authorization: 'Bearer ' + token } });
    if (!response?.ok) throw new Error(response?.payload?.error || 'Connexion à Eraser impossible.');
    if (!Array.isArray(response.payload?.sessions)) throw new Error('Mets à jour l’application Eraser pour synchroniser une session.');
    return response.payload.sessions;
  }

  function dateLabel(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  // Menu déroulant : de la plus récente à la plus ancienne, filtré par la recherche.
  function renderSessions() {
    const select = document.getElementById('eraser-roll20-session');
    const search = document.getElementById('eraser-roll20-session-search');
    if (!select) return;
    const query = (search?.value || '').trim().toLocaleLowerCase('fr');
    const previous = select.value;
    const visible = sessionList.filter((session) => !query || String(session.name).toLocaleLowerCase('fr').includes(query));
    select.replaceChildren(...visible.map((session) => {
      const option = document.createElement('option');
      option.value = session.id;
      const date = dateLabel(session.createdAt);
      option.textContent = session.name + (date ? ' — ' + date : '') + ' (' + (session.npcCount || 0) + ' PNJ · ' + (session.shopCount || 0) + ' magasin(s)' + (session.documentCount ? ' · ' + session.documentCount + ' document(s)' : '') + ')';
      return option;
    }));
    if (!visible.length) {
      const option = document.createElement('option');
      option.value = ''; option.textContent = sessionList.length ? 'Aucune session ne correspond' : 'Aucune session dans Eraser';
      select.append(option);
    }
    if (visible.some((session) => session.id === previous)) select.value = previous;
  }

  async function openSessionPicker() {
    openPanel();
    const box = document.getElementById('eraser-roll20-sessions');
    if (!box) return;
    box.hidden = false;
    status('Chargement des sessions…');
    try {
      sessionList = await fetchSessions();
      renderSessions();
      status(sessionList.length ? 'Choisis la session à synchroniser.' : 'Aucune session : crée-en une dans le Créateur de session d’Eraser.', !sessionList.length);
    } catch (error) { status(error.message || String(error), true); }
  }

  /* ---------- synchronisation ---------- */
  /**
   * `scope` vide : tout (ou la session `sessionId`). « players » : seulement les personnages
   * joueurs (nom, PV, profil, portrait, token). « documents » : seulement les documents.
   */
  async function syncAll(sessionId, scope) {
    if (syncing || !IS_TOP) return;
    syncing = true; openPanel();
    const started = Date.now();
    try {
      status('Vérification du script Mod Roll20…');
      await checkModBridge();
      status(scope === 'players' ? 'Chargement des personnages joueurs…' : scope === 'documents' ? 'Chargement des documents…' : sessionId ? 'Chargement de la session…' : 'Chargement de la campagne…');
      const payload = await fetchCampaign(sessionId, scope);
      if (!Array.isArray(payload.npcs) || !Array.isArray(payload.shops)) throw new Error('Eraser a renvoyé une campagne invalide. Vérifie la clé de liaison.');
      const characters = Array.isArray(payload.characters) ? payload.characters : [];
      // Une application Eraser plus ancienne ne connaît pas les documents.
      const documents = Array.isArray(payload.documents) ? payload.documents : [];
      // Les créatures des événements de session (Eraser alpha 295 et suivantes).
      const creatures = Array.isArray(payload.creatures) ? payload.creatures : [];
      const total = characters.length + payload.npcs.length + creatures.length + payload.shops.length + documents.length;
      if (!total) throw new Error(scope === 'players' ? 'Aucun personnage joueur dans cette campagne Eraser.' : scope === 'documents' ? 'Aucun document dans cette campagne Eraser : écris-en un dans la page Document.' : payload.session ? 'La session « ' + payload.session.name + ' » ne contient aucun joueur, PNJ, créature, magasin ni document.' : 'Eraser a renvoyé 0 PNJ et 0 magasin. Ajoute des PNJ ou des magasins à une session dans le Créateur de session.');
      // Une session range ses PNJs, magasins et documents dans un dossier à son nom (les joueurs ne bougent pas).
      const folder = payload.session ? payload.session.name : '';
      const documentFolder = folder || 'Documents Eraser';

      const failures = [];
      const warnings = [];
      let imported = 0, beasts = 0, players = 0, tokens = 0, eraserTokens = 0, autoTokens = 0, portraits = 0, shops = 0, docs = 0, pdfs = 0, done = 0;
      const filed = [];
      const filedDocuments = [];
      const collect = (report, fileInFolder) => {
        failures.push(...report.failures); warnings.push(...report.warnings);
        if (report.portrait) portraits += 1;
        if (report.token) tokens += 1;
        if (report.eraserToken) eraserTokens += 1;
        if (report.autoToken) autoTokens += 1;
        if (fileInFolder && report.characterId) filed.push(report.characterId);
        return report.imported;
      };

      for (const character of characters) {
        const label = 'Joueur ' + (++done) + '/' + total + ' — ' + character.name;
        status(label);
        if (collect(await importWithImages(payload, 'character', character, label, ''))) players += 1;
      }
      for (const npc of payload.npcs) {
        const label = 'PNJ ' + (++done) + '/' + total + ' — ' + npc.name;
        status(label);
        if (collect(await importWithImages(payload, 'npc', npc, label, folder), true)) imported += 1;
      }
      for (const creature of creatures) {
        const label = 'Créature ' + (++done) + '/' + total + ' — ' + creature.name;
        status(label);
        if (collect(await importWithImages(payload, 'creature', creature, label, folder), true)) beasts += 1;
      }
      for (const shop of payload.shops) {
        const label = 'Magasin ' + (++done) + '/' + total + ' — ' + shop.name;
        status(label);
        if (collect(await importWithImages(payload, 'shop', shop, label, folder), true)) shops += 1;
      }
      for (const doc of documents) {
        const label = 'Document ' + (++done) + '/' + total + ' — ' + doc.name;
        status(label);
        const report = await importDocument(payload, doc, label, documentFolder);
        failures.push(...report.failures); warnings.push(...report.warnings);
        if (report.imported) { docs += 1; filedDocuments.push(report.characterId); }
        if (report.pdf) pdfs += 1;
      }

      // Les PNJs, créatures et magasins de la session vont dans son dossier ; les joueurs ne bougent pas.
      let folderNote = '';
      if (folder && filed.length) {
        status('Rangement dans le dossier « ' + folder + ' »…');
        try { folderNote = ' · ' + (await moveToJournalFolder(folder, filed)) + ' fiche(s) dans le dossier « ' + folder + ' »'; }
        catch (error) { failures.push('Dossier « ' + folder + ' » — ' + error.message); }
      }
      if (filedDocuments.length) {
        status('Rangement des documents dans « ' + documentFolder + ' »…');
        try { await moveToJournalFolder(documentFolder, filedDocuments); }
        catch (error) { failures.push('Dossier « ' + documentFolder + ' » — ' + error.message); }
      }

      await sendCommand('!eraser-import-done');
      const seconds = Math.round((Date.now() - started) / 1000);
      const withToken = characters.concat(payload.npcs, creatures, payload.shops).filter((entry) => entry.tokenUrl).length;
      const documentNote = documents.length ? ' · ' + docs + '/' + documents.length + ' document(s), ' + pdfs + ' PDF déposé(s)' : '';
      const summary = scope === 'players'
        ? 'Personnages joueurs · ' + players + '/' + characters.length + ' à jour · ' + tokens + ' jeton(s) OK · ' + portraits + ' portrait(s) · ' + eraserTokens + ' token(s) Eraser · ' + autoTokens + ' token(s) par défaut · ' + seconds + ' s'
        : scope === 'documents'
          ? 'Documents · ' + docs + '/' + documents.length + ' handout(s) · ' + pdfs + ' PDF déposé(s) dans le Journal · ' + seconds + ' s'
          : (payload.session ? 'Session « ' + payload.session.name + ' » · ' : 'Tout · ') + players + '/' + characters.length + ' joueur(s) · ' + imported + '/' + payload.npcs.length + ' PNJ · ' + (creatures.length ? beasts + '/' + creatures.length + ' créature(s) · ' : '') + shops + '/' + payload.shops.length + ' magasin(s) · ' + tokens + ' jeton(s) OK · ' + portraits + ' portrait(s) importé(s) · ' + eraserTokens + ' token(s) Eraser importé(s) sur ' + withToken + ' préparé(s) · ' + autoTokens + ' token(s) par défaut' + documentNote + folderNote + ' · ' + seconds + ' s';
      if (failures.length) status('Synchronisation incomplète — ' + summary + '\n\n' + failures.concat(warnings).join('\n'), true);
      else if (warnings.length) status('Synchronisation faite — ' + summary + '\n\n' + warnings.join('\n') + '\n\nAstuce : sélectionne un jeton puis « !eraser-placeholder » pour donner une image par défaut aux PNJ sans portrait.', false);
      else status('Synchronisation terminée — ' + summary);
    } catch (error) {
      status(error.message || String(error), true);
    } finally {
      syncing = false;
    }
  }

  async function resetAllImports() {
    if (!window.confirm('Supprimer les PNJ, créatures, magasins et documents créés par Eraser dans cette partie Roll20, puis repartir de zéro ? (Les PDF déposés dans le Journal restent à supprimer à la main.)')) return;
    try {
      const result = await command('!eraser-reset-all', null, 15000);
      await storageSet({ eraserPdfs: {} });
      status((result.removed || 0) + ' import(s) Eraser supprimé(s). Tu peux relancer une synchronisation.');
    } catch (error) { status(error.message || String(error), true); }
  }

  async function pushHp(encoded) {
    try {
      const token = await storageGet('eraserToken');
      if (!token) throw new Error('Clé Eraser absente.');
      const response = await bridgeFetch({ url: API, method: 'PATCH', headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json' }, body: JSON.stringify(decode(encoded)) });
      if (!response?.ok) throw new Error(response?.payload?.error || 'Retour des PV impossible.');
      openPanel(); status(response.payload.updated + ' PNJ mis à jour dans Eraser.');
    } catch (error) { openPanel(); status(error.message || String(error), true); }
  }

  /* ---------- observation du chat ---------- */
  const handledEvents = new Set();
  // Les demandes déjà dans le chat à l'ouverture de la page sont anciennes : jamais rejouées.
  const handledRequests = new Set();
  const requestPattern = /ERASER_SYNC(_SESSION|_PLAYERS|_DOCUMENTS)?_REQUEST:([A-Za-z0-9]+)_([A-Za-z0-9]+)/g;
  // Roll20 recharge l'historique du chat après l'ouverture : une demande plus
  // ancienne que la page (à 30 s près pour l'écart d'horloge) n'est pas rejouée.
  const pageOpenedAt = Date.now();
  function primeRequests(root) { for (const match of String(root?.textContent || '').matchAll(requestPattern)) handledRequests.add(match[2] + '_' + match[3]); }
  function newRequests(text) {
    const found = [];
    for (const match of String(text || '').matchAll(requestPattern)) {
      const id = match[2] + '_' + match[3];
      if (handledRequests.has(id)) continue;
      handledRequests.add(id);
      if (parseInt(match[2], 36) < pageOpenedAt - 30000) continue;
      found.push(match[1] === '_SESSION' ? 'session' : match[1] === '_PLAYERS' ? 'players' : match[1] === '_DOCUMENTS' ? 'documents' : 'all');
    }
    return found;
  }
  function watchChat() {
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) for (const node of mutation.addedNodes) {
        const text = (node.nodeType === Node.TEXT_NODE ? node.parentElement?.textContent : node.textContent) || '';
        scanAcknowledgements(text);
        if (!IS_TOP) continue;
        // Seul le texte ajouté compte pour une demande : relire le parent rejouait
        // d'anciennes demandes « Tout synchroniser » restées dans le chat.
        for (const request of newRequests(node.textContent || '')) {
          if (request === 'session') void openSessionPicker();
          else if (request === 'players' || request === 'documents') void syncAll('', request);
          else void syncAll();
        }
        const hp = text.match(/ERASER_HP:([A-Za-z0-9_-]+)/);
        if (hp && !handledEvents.has(hp[1])) { handledEvents.add(hp[1]); void pushHp(hp[1]); }
        observeNestedRoots(observer, node);
      }
    });
    primeRequests(document.body);
    observeChatRoot(observer, document.body);
    acknowledgementPoll = acknowledgementPoll || setInterval(() => { if (acknowledgements.size) scanAllChatRoots(); }, 300);
  }
  function observeChatRoot(observer, root) {
    if (!root || observedRoots.has(root)) return;
    observedRoots.add(root);
    chatRootList.push(root);
    observer.observe(root, { childList: true, characterData: true, subtree: true });
    observeNestedRoots(observer, root);
  }
  function observeNestedRoots(observer, node) {
    if (node?.shadowRoot) observeChatRoot(observer, node.shadowRoot);
    for (const element of node?.querySelectorAll?.('*') || []) if (element.shadowRoot) observeChatRoot(observer, element.shadowRoot);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const ack = changes.eraserLastAcknowledgement?.newValue;
    if (ack?.id) acknowledgements.get(ack.id)?.resolve(ack.metadata);
  });

  async function mount() {
    if (document.getElementById('eraser-roll20-button')) return;
    const button = document.createElement('button');
    button.id = 'eraser-roll20-button'; button.textContent = 'Eraser'; button.type = 'button';
    const panel = document.createElement('aside');
    panel.id = 'eraser-roll20-panel';
    panel.innerHTML = '<div class="eraser-head"><strong>Eraser ↔ Roll20 <small style="opacity:.6">' + VERSION + '</small></strong><button type="button" data-close>×</button></div>'
      + '<label>Clé de liaison<input type="password" id="eraser-roll20-token" autocomplete="off" placeholder="era_…"></label>'
      + '<div class="eraser-actions"><button type="button" data-save>Enregistrer la clé</button><button type="button" data-sync>Tout synchroniser</button><button type="button" data-sessions>Synchroniser une session</button><button type="button" data-players>Mettre à jour les personnages joueurs</button><button type="button" data-documents>Synchroniser les documents</button></div>'
      + '<div id="eraser-roll20-sessions" hidden><label>Session<input type="search" id="eraser-roll20-session-search" autocomplete="off" placeholder="Rechercher par nom…"></label><select id="eraser-roll20-session" aria-label="Session à synchroniser"></select><div class="eraser-actions"><button type="button" data-sync-session>Synchroniser cette session</button></div></div>'
      + '<div class="eraser-actions"><button type="button" data-hp>Renvoyer les PV</button><button type="button" data-reset>Effacer les imports Eraser / repartir de zéro</button></div>'
      + '<p id="eraser-roll20-status">Prêt.</p>';
    document.body.append(button, panel);
    button.addEventListener('click', openPanel);
    panel.querySelector('[data-close]').addEventListener('click', closePanel);
    panel.querySelector('[data-save]').addEventListener('click', async () => {
      const token = panel.querySelector('#eraser-roll20-token').value.trim();
      if (!token.startsWith('era_')) return status('Cette clé n’est pas valide.', true);
      await storageSet({ eraserToken: token }); status('Clé enregistrée.');
    });
    panel.querySelector('[data-sync]').addEventListener('click', () => syncAll());
    panel.querySelector('[data-sessions]').addEventListener('click', openSessionPicker);
    panel.querySelector('[data-players]').addEventListener('click', () => syncAll('', 'players'));
    panel.querySelector('[data-documents]').addEventListener('click', () => syncAll('', 'documents'));
    panel.querySelector('#eraser-roll20-session-search').addEventListener('input', renderSessions);
    panel.querySelector('[data-sync-session]').addEventListener('click', () => {
      const sessionId = panel.querySelector('#eraser-roll20-session').value;
      if (!sessionId) return status('Choisis d’abord une session.', true);
      void syncAll(sessionId);
    });
    panel.querySelector('[data-hp]').addEventListener('click', () => sendCommand('!eraser-push-hp').catch((error) => status(error.message, true)));
    panel.querySelector('[data-reset]').addEventListener('click', resetAllImports);
    panel.querySelector('#eraser-roll20-token').value = await storageGet('eraserToken');
    watchChat();
  }

  // Eraser a rangé une version plus récente dans le dossier du compagnon : le compagnon se
  // recharge depuis ce dossier, puis la page Roll20 aussi (sinon elle garderait l'ancien code).
  async function selfUpdate() {
    const result = await runtimeMessage({ type: 'eraser-self-update' });
    if (result?.reloading) {
      const button = document.getElementById('eraser-roll20-button');
      if (button) button.textContent = 'Eraser ↻ ' + result.version;
      setTimeout(() => location.reload(), 1500);
    } else if (result?.otherFolder) {
      status('Eraser a rangé le compagnon ' + result.otherFolder + ' dans son dossier, mais le navigateur en charge un autre (' + VERSION + '). Dans la page des extensions, retire celui-ci puis « Charger l’extension non empaquetée » depuis le dossier choisi dans Eraser.', true);
    }
  }

  const start = () => (IS_TOP ? Promise.resolve(mount()).then(selfUpdate).catch(() => {}) : watchChat());
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => void start()); else void start();
}());
